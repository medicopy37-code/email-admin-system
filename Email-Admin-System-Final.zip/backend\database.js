const sqlite3 = require('sqlite3').verbose();
const bcrypt = require('bcryptjs');
const path = require('path');

const DB_PATH = process.env.DB_PATH || './database.sqlite';

class Database {
  constructor() {
    this.db = new sqlite3.Database(DB_PATH, (err) => {
      if (err) {
        console.error('Error opening database:', err);
      } else {
        console.log('✅ Connected to SQLite database');
        this.init();
      }
    });
  }

  init() {
    this.db.serialize(() => {
      // Admin users table
      this.db.run(`
        CREATE TABLE IF NOT EXISTS admins (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          email TEXT UNIQUE NOT NULL,
          password TEXT NOT NULL,
          name TEXT,
          created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )
      `);

      // Managed email accounts table
      this.db.run(`
        CREATE TABLE IF NOT EXISTS email_accounts (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          email TEXT UNIQUE NOT NULL,
          provider TEXT NOT NULL,
          encrypted_password TEXT NOT NULL,
          display_name TEXT,
          status TEXT DEFAULT 'active',
          created_by INTEGER,
          created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
          last_accessed DATETIME,
          FOREIGN KEY (created_by) REFERENCES admins(id)
        )
      `);

      // Users who can access emails table
      this.db.run(`
        CREATE TABLE IF NOT EXISTS delegated_users (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          username TEXT UNIQUE NOT NULL,
          password TEXT NOT NULL,
          name TEXT,
          status TEXT DEFAULT 'active',
          created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )
      `);

      // Access permissions table
      this.db.run(`
        CREATE TABLE IF NOT EXISTS access_permissions (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          user_id INTEGER NOT NULL,
          email_account_id INTEGER NOT NULL,
          can_read INTEGER DEFAULT 1,
          can_send INTEGER DEFAULT 1,
          granted_at DATETIME DEFAULT CURRENT_TIMESTAMP,
          FOREIGN KEY (user_id) REFERENCES delegated_users(id),
          FOREIGN KEY (email_account_id) REFERENCES email_accounts(id),
          UNIQUE(user_id, email_account_id)
        )
      `);

      // Activity logs table
      this.db.run(`
        CREATE TABLE IF NOT EXISTS activity_logs (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          user_id INTEGER,
          email_account_id INTEGER,
          action TEXT NOT NULL,
          details TEXT,
          ip_address TEXT,
          timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
          FOREIGN KEY (user_id) REFERENCES delegated_users(id),
          FOREIGN KEY (email_account_id) REFERENCES email_accounts(id)
        )
      `);

      // Create default admin if doesn't exist
      const adminEmail = process.env.ADMIN_EMAIL || 'admin@localhost';
      const adminPassword = process.env.ADMIN_PASSWORD || 'Admin@123456';

      this.db.get('SELECT * FROM admins WHERE email = ?', [adminEmail], (err, row) => {
        if (!row) {
          const hashedPassword = bcrypt.hashSync(adminPassword, 10);
          this.db.run(
            'INSERT INTO admins (email, password, name) VALUES (?, ?, ?)',
            [adminEmail, hashedPassword, 'System Admin'],
            (err) => {
              if (err) {
                console.error('Error creating default admin:', err);
              } else {
                console.log('✅ Default admin created:', adminEmail);
                console.log('🔑 Password:', adminPassword);
              }
            }
          );
        }
      });
    });
  }

  // Helper methods
  run(sql, params = []) {
    return new Promise((resolve, reject) => {
      this.db.run(sql, params, function(err) {
        if (err) reject(err);
        else resolve({ id: this.lastID, changes: this.changes });
      });
    });
  }

  get(sql, params = []) {
    return new Promise((resolve, reject) => {
      this.db.get(sql, params, (err, row) => {
        if (err) reject(err);
        else resolve(row);
      });
    });
  }

  all(sql, params = []) {
    return new Promise((resolve, reject) => {
      this.db.all(sql, params, (err, rows) => {
        if (err) reject(err);
        else resolve(rows);
      });
    });
  }
}

module.exports = new Database();
