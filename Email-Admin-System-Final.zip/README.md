# 📧 Email Admin Control System

A complete email management system that gives you **full administrative control** over Gmail and Outlook accounts.

## 🎯 Key Features

- ✅ **Full Admin Control** - Manage all email passwords (users never see them)
- ✅ **User Portal** - Delegated users access emails through your system
- ✅ **Permission Management** - Grant/revoke read and send access
- ✅ **Activity Logging** - Track who accessed what and when
- ✅ **Multi-Provider** - Works with Gmail, Outlook, Hotmail
- ✅ **Secure** - Encrypted password storage, JWT authentication
- ✅ **Responsive UI** - Works on desktop and mobile

## 🚀 Quick Start (5 Minutes)

### 1. Install Dependencies

```bash
# Backend
cd backend
npm install

# Frontend (open new terminal)
cd frontend
npm install
```

### 2. Configure Backend

```bash
cd backend
cp .env.example .env
nano .env  # Edit with your settings
```

Minimum required settings in `.env`:
```env
JWT_SECRET=your_super_secret_jwt_key_32_chars
ENCRYPTION_KEY=your_encryption_key_32_chars
ADMIN_EMAIL=admin@localhost
ADMIN_PASSWORD=Admin@123456
```

### 3. Start the System

```bash
# Terminal 1 - Backend
cd backend
npm start

# Terminal 2 - Frontend
cd frontend
npm start
```

### 4. Access the System

- Frontend: http://localhost:3000
- Backend API: http://localhost:5000

**Default Admin Login:**
- Email: `admin@localhost`
- Password: `Admin@123456`

## 📖 Full Documentation

See [SETUP_GUIDE.md](./SETUP_GUIDE.md) for:
- Complete setup instructions
- Gmail App Password setup
- Production deployment (Heroku, AWS, DigitalOcean)
- User management
- Troubleshooting
- Security best practices

## 🏗️ System Architecture

```
┌─────────────────┐
│  Admin/User     │
│  (Web Browser)  │
└────────┬────────┘
         │
    ┌────▼─────┐
    │  React   │
    │ Frontend │
    └────┬─────┘
         │ HTTP/REST
    ┌────▼─────┐
    │ Express  │
    │  Backend │
    └────┬─────┘
         │
    ┌────▼─────┐
    │  SQLite  │
    │ Database │
    └──────────┘
```

## 📁 Project Structure

```
email-admin-system/
├── backend/
│   ├── server.js          # Main Express server
│   ├── database.js        # SQLite database
│   ├── auth.js            # JWT authentication
│   ├── encryption.js      # Password encryption
│   ├── gmailService.js    # Gmail integration
│   ├── outlookService.js  # Outlook integration
│   └── .env               # Configuration
│
├── frontend/
│   ├── src/
│   │   ├── components/
│   │   │   ├── AdminLogin.js
│   │   │   ├── UserLogin.js
│   │   │   ├── AdminDashboard.js
│   │   │   └── UserDashboard.js
│   │   ├── App.js
│   │   └── api.js         # API client
│   └── package.json
│
└── SETUP_GUIDE.md         # Complete documentation
```

## 🔒 Security Features

- **Encrypted Passwords** - All email passwords encrypted in database
- **JWT Authentication** - Secure token-based auth
- **Role-Based Access** - Separate admin and user roles
- **Activity Logging** - Complete audit trail
- **Permission System** - Granular read/send permissions
- **No Direct Access** - Users never access emails directly

## 📊 Database Schema

### Tables:
- `admins` - Admin users
- `email_accounts` - Managed email accounts (passwords encrypted)
- `delegated_users` - Users who can access emails
- `access_permissions` - User → Email access mapping
- `activity_logs` - All user actions

## 🌐 Deployment Options

- **Heroku** - Free tier available, easiest deployment
- **Render.com** - Free tier, simple setup
- **DigitalOcean** - $5/month VPS
- **AWS** - Scalable, pay-as-you-go
- **Self-hosted** - Any VPS with Node.js

See [SETUP_GUIDE.md](./SETUP_GUIDE.md) for detailed deployment instructions.

## 🔧 Tech Stack

**Backend:**
- Node.js + Express
- SQLite database
- JWT authentication
- Nodemailer (email sending)
- Google APIs (Gmail)
- CryptoJS (encryption)

**Frontend:**
- React 18
- React Router
- Axios
- React Icons
- Responsive CSS

## 📝 Common Use Cases

1. **Small Business** - Manage support@, sales@, info@ emails centrally
2. **Team Collaboration** - Give team members access without sharing passwords
3. **Client Management** - Manage client email accounts securely
4. **Family/Group** - Share family email access with controlled permissions
5. **Freelancers** - Manage multiple client email accounts

## 🎯 Workflow Example

1. **Admin adds Gmail account** (support@company.com)
2. **Admin creates user** (john_doe)
3. **Admin grants access** to john_doe for support@company.com
4. **John logs in** and sees only support@company.com emails
5. **John sends email** from support@company.com
6. **Activity logged** - Admin sees John sent email at 2:30 PM
7. **Admin revokes access** - John immediately loses access

## ⚠️ Important Notes

### For Gmail:
- You MUST use **App Passwords**, not regular passwords
- Enable 2-Factor Authentication first
- Generate App Password at: myaccount.google.com/apppasswords

### For Outlook/Hotmail:
- Can use regular password
- If 2FA enabled, use App Password
- Some accounts may need "Less secure app access" enabled

### What Users CANNOT Do:
- ❌ See actual email passwords
- ❌ Change passwords
- ❌ Delete accounts
- ❌ Access emails not granted to them

### What Admins CAN Do:
- ✅ Full control over everything
- ✅ Add/remove accounts instantly
- ✅ Grant/revoke access anytime
- ✅ View all activity logs
- ✅ Reset user passwords

## 🆘 Troubleshooting

**Backend won't start:**
```bash
cd backend
rm -rf node_modules package-lock.json
npm install
npm start
```

**Frontend won't start:**
```bash
cd frontend
rm -rf node_modules package-lock.json
npm install
npm start
```

**Can't add Gmail account:**
- Use App Password, NOT regular password
- Enable 2FA first
- Generate new App Password

**Emails not loading:**
- Check account status is "active"
- Verify user has "Can Read" permission
- Test email credentials by re-adding

## 📄 License

MIT License - Free to use, modify, and distribute.

## 🤝 Contributing

This is a complete, production-ready system. Feel free to:
- Fork and customize
- Add new email providers
- Enhance the UI
- Add features (2FA, email filters, etc.)

## 🎉 Credits

Built with ❤️ as a complete solution for email administration with full control.

---

**Need Help?** Check [SETUP_GUIDE.md](./SETUP_GUIDE.md) for detailed documentation.
