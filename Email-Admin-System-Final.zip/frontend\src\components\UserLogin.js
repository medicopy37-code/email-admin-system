import React, { useState } from 'react';
import { userLogin } from '../api';
import './Login.css';

function UserLogin({ onLoginSuccess }) {
  const [username, setUsername] = useState('abhishekrajj77@gmail.com');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      const response = await userLogin(username, password);

      localStorage.setItem('token', response.data.token);
      localStorage.setItem('role', 'user');
      localStorage.setItem('user', JSON.stringify(response.data.user));

      onLoginSuccess('user', response.data.user);

    } catch (err) {
      setError(err.response?.data?.error || 'Login failed');
    } finally {
      setLoading(false);
    }
  };

  // Logout Function Added
  const logout = () => {
    localStorage.clear();
    window.location.href = "/login";
  };

  return (
    <div className="login-container">
      <div className="login-card">

        {/* Logout Button Added */}
        <button
          onClick={logout}
          className="btn btn-secondary"
          style={{ float: 'right', marginBottom: '15px' }}
        >
          Logout
        </button>

        <div className="login-header">
          <h1>👤 User Login</h1>
          <p>Access your delegated email accounts</p>
        </div>

        {error && <div className="alert alert-error">{error}</div>}

        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <label>Username</label>
            <input
              type="text"
              className="input"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              placeholder="Enter username"
              required
            />
          </div>

          <div className="form-group">
            <label>Password</label>
            <input
              type="password"
              className="input"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Enter password"
              required
            />
          </div>

          <button
            type="submit"
            className="btn btn-primary btn-block"
            disabled={loading}
          >
            {loading ? 'Logging in...' : 'Login'}
          </button>
        </form>

      </div>
    </div>
  );
}

export default UserLogin;