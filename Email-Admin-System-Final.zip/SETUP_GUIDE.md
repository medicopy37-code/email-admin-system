# 📧 Email Admin Control System - Complete Setup Guide

## 🎯 What This System Does

This system gives you **FULL ADMIN CONTROL** over Gmail/Outlook accounts where:
- ✅ You store and manage all passwords (encrypted)
- ✅ Users access emails through YOUR portal
- ✅ Users CANNOT change passwords or delete accounts
- ✅ You can grant/revoke access anytime
- ✅ Complete activity logging
- ✅ Works with @gmail.com, @outlook.com, @hotmail.com

---

## 🚀 Quick Start (Local Development)

### Prerequisites
- Node.js 16+ installed
- npm or yarn
- Basic terminal knowledge

### Step 1: Setup Backend

```bash
cd backend
npm install
cp .env.example .env
```

Edit `.env` file:
```env
PORT=5000
JWT_SECRET=change_this_to_random_string_32_chars
ENCRYPTION_KEY=another_random_32_character_key_here
ADMIN_EMAIL=admin@localhost
ADMIN_PASSWORD=Admin@123456
```

Start backend:
```bash
npm start
```

Backend will run on http://localhost:5000

### Step 2: Setup Frontend

Open NEW terminal:
```bash
cd frontend
npm install
npm start
```

Frontend will open automatically at http://localhost:3000

### Step 3: First Login

1. Open http://localhost:3000
2. Click "Admin Login"
3. Use credentials:
   - Email: `admin@localhost`
   - Password: `Admin@123456`

---

## 📧 Setting Up Gmail Accounts

### For Gmail (@gmail.com)

Gmail requires **App Passwords** (not your regular password):

1. **Enable 2-Factor Authentication:**
   - Go to myaccount.google.com/security
   - Enable 2-Step Verification

2. **Generate App Password:**
   - Go to myaccount.google.com/apppasswords
   - Select "Mail" and "Other (Custom name)"
   - Name it: "Email Admin System"
   - Click Generate
   - Copy the 16-character password (e.g., `abcd efgh ijkl mnop`)

3. **Add to System:**
   - In Admin Dashboard → Email Accounts → Add Email Account
   - Email: your.email@gmail.com
   - Password: (paste the 16-character app password)
   - Provider: Gmail
   - Click Add

### For Outlook/Hotmail (@outlook.com, @hotmail.com)

Outlook is easier - just use your regular password:

1. **Add to System:**
   - In Admin Dashboard → Email Accounts → Add Email Account
   - Email: your.email@outlook.com
   - Password: (your regular Outlook password)
   - Provider: Outlook
   - Click Add

**Note:** If you have 2FA enabled on Outlook, you'll need to create an "App Password" similar to Gmail.

---

## 👥 Creating Users & Granting Access

### Step 1: Create a Delegated User

1. Go to "Delegated Users" tab
2. Click "Create User"
3. Fill in:
   - Username: `john_doe`
   - Password: `SecurePass123`
   - Name: `John Doe`
4. Click Create

### Step 2: Grant Email Access

1. Go to "Access Control" tab
2. Click "Grant Access"
3. Select:
   - User: John Doe
   - Email Account: support@gmail.com
   - Permissions: ✓ Can Read, ✓ Can Send
4. Click Grant Access

### Step 3: User Login

Now John can login at http://localhost:3000:
- Click "User Login"
- Username: `john_doe`
- Password: `SecurePass123`

He will see only the emails you granted him access to!

---

## 🔒 Security Features

### What Users CANNOT Do:
- ❌ See the actual email passwords
- ❌ Change email passwords
- ❌ Delete email accounts
- ❌ Access emails you haven't granted
- ❌ Grant access to other users

### What Admins CAN Do:
- ✅ Add/remove email accounts
- ✅ Create/delete users
- ✅ Grant/revoke access anytime
- ✅ Activate/deactivate accounts instantly
- ✅ View all activity logs
- ✅ Change user passwords

---

## 🌐 Production Deployment

### Option 1: Deploy to Heroku (Easiest - Free Tier Available)

#### Backend Deployment:

```bash
cd backend

# Install Heroku CLI: https://devcenter.heroku.com/articles/heroku-cli
heroku login
heroku create your-email-admin-api

# Set environment variables
heroku config:set JWT_SECRET=your_random_jwt_secret_32_chars
heroku config:set ENCRYPTION_KEY=your_random_encryption_key_32_chars
heroku config:set ADMIN_EMAIL=admin@yourdomain.com
heroku config:set ADMIN_PASSWORD=YourStrongPassword123

# Deploy
git init
git add .
git commit -m "Initial commit"
heroku git:remote -a your-email-admin-api
git push heroku master

# Your API will be at: https://your-email-admin-api.herokuapp.com
```

#### Frontend Deployment:

```bash
cd frontend

# Update .env to point to your Heroku backend
echo "REACT_APP_API_URL=https://your-email-admin-api.herokuapp.com/api" > .env

# Build
npm run build

# Deploy to Netlify (free)
# 1. Go to netlify.com
# 2. Drag and drop the 'build' folder
# OR use Netlify CLI:
npm install -g netlify-cli
netlify deploy --prod --dir=build
```

### Option 2: Deploy to DigitalOcean/AWS/VPS

#### Requirements:
- Ubuntu 20.04+ VPS
- Domain name (optional but recommended)

#### Setup Script:

```bash
# SSH into your VPS
ssh root@your-vps-ip

# Install Node.js
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt-get install -y nodejs

# Install PM2 (Process Manager)
sudo npm install -g pm2

# Clone your repository
git clone https://github.com/yourusername/email-admin-system.git
cd email-admin-system

# Setup Backend
cd backend
npm install
cp .env.example .env
nano .env  # Edit with your settings

# Start backend with PM2
pm2 start server.js --name email-admin-api
pm2 save
pm2 startup

# Setup Frontend
cd ../frontend
npm install
npm run build

# Install Nginx
sudo apt install nginx -y

# Configure Nginx
sudo nano /etc/nginx/sites-available/email-admin
```

Nginx configuration:
```nginx
server {
    listen 80;
    server_name your-domain.com;

    # Frontend
    location / {
        root /path/to/email-admin-system/frontend/build;
        try_files $uri /index.html;
    }

    # Backend API
    location /api {
        proxy_pass http://localhost:5000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }
}
```

```bash
# Enable site
sudo ln -s /etc/nginx/sites-available/email-admin /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl restart nginx

# Setup SSL with Let's Encrypt (free HTTPS)
sudo apt install certbot python3-certbot-nginx -y
sudo certbot --nginx -d your-domain.com
```

### Option 3: Deploy to Render.com (Free Tier)

1. **Backend:**
   - Go to render.com
   - New → Web Service
   - Connect GitHub repo
   - Build Command: `cd backend && npm install`
   - Start Command: `cd backend && npm start`
   - Add environment variables in dashboard

2. **Frontend:**
   - New → Static Site
   - Build Command: `cd frontend && npm install && npm run build`
   - Publish Directory: `frontend/build`

---

## 📊 Database Management

### Backup Database

```bash
# SQLite database is a single file: backend/database.sqlite
cp backend/database.sqlite backend/database.backup.sqlite
```

### Reset Database

```bash
rm backend/database.sqlite
npm start  # Will recreate with default admin
```

### View Database Contents

```bash
sqlite3 backend/database.sqlite
.tables
SELECT * FROM admins;
SELECT * FROM email_accounts;
SELECT * FROM delegated_users;
.exit
```

---

## 🔧 Troubleshooting

### "Failed to connect" when adding Gmail

**Solution:** Make sure you're using App Password, not regular password.

### "Invalid credentials" when adding Outlook

**Solution:** 
- Check if password is correct
- Disable 2FA temporarily, or create App Password
- Try enabling "Less secure app access" (not recommended)

### Emails not loading

**Check:**
1. Email account status is "active"
2. User has "Can Read" permission
3. Password is correct (try re-adding the account)
4. Gmail: App password hasn't expired
5. Outlook: Account isn't locked

### Backend won't start

**Check:**
```bash
cd backend
rm package-lock.json
rm -rf node_modules
npm install
npm start
```

### Frontend won't start

**Check:**
```bash
cd frontend
rm package-lock.json
rm -rf node_modules
npm install
npm start
```

---

## 🎨 Customization

### Change Admin Credentials

Edit `backend/.env`:
```env
ADMIN_EMAIL=youradmin@yourdomain.com
ADMIN_PASSWORD=YourNewStrongPassword
```

Restart backend:
```bash
rm backend/database.sqlite  # This resets everything
npm start
```

### Add More Email Providers

Edit `backend/server.js` to add support for Yahoo, ProtonMail, etc.

### Change UI Colors

Edit `frontend/src/index.css`:
```css
:root {
  --primary-color: #your-color;
  --secondary-color: #your-color;
}
```

---

## 📱 Mobile Access

The system is fully responsive and works on:
- ✅ Desktop browsers
- ✅ Mobile browsers (iOS Safari, Chrome)
- ✅ Tablets

No app installation needed - just open the URL!

---

## 🔐 Security Best Practices

1. **Change Default Credentials** immediately after first login
2. **Use Strong Passwords** for admin and encryption keys
3. **Enable HTTPS** in production (use Let's Encrypt)
4. **Regular Backups** of database.sqlite file
5. **Update Dependencies** regularly:
   ```bash
   npm update
   ```
6. **Monitor Activity Logs** for suspicious behavior
7. **Use App Passwords** for Gmail (never regular passwords)
8. **Limit User Permissions** - only grant what's needed

---

## 📞 Support & Next Steps

### Common Tasks:

**Add 10 email accounts:**
1. Get Gmail App Passwords for all accounts
2. Add each via Admin Dashboard
3. Test by sending a test email

**Give access to 5 team members:**
1. Create 5 users in "Delegated Users"
2. Grant each user access to relevant emails
3. Share their login credentials securely

**Revoke access:**
1. Go to Access Control
2. Find the permission
3. Click Revoke (instant effect)

**Monitor activity:**
1. Check "Activity Logs" tab
2. See who accessed what and when
3. Export logs if needed

---

## 🎉 You're All Set!

Your email admin system is now ready to use. You have:
- ✅ Full control over all email accounts
- ✅ User management with granular permissions
- ✅ Activity logging and monitoring
- ✅ Secure password storage
- ✅ Works with Gmail, Outlook, Hotmail

**Next:** Start adding your email accounts and creating users!
