#!/bin/bash

# Quick Start Script for Email Admin System

echo "📧 Email Admin System - Quick Start"
echo "===================================="

# Check if Node.js is installed
if ! command -v node &> /dev/null; then
    echo "❌ Node.js is not installed!"
    echo "Please install Node.js from: https://nodejs.org/"
    exit 1
fi

echo "✓ Node.js $(node --version) detected"
echo "✓ npm $(npm --version) detected"
echo ""

# Setup Backend
echo "🔧 Setting up Backend..."
cd backend

if [ ! -f ".env" ]; then
    echo "Creating .env file..."
    cp .env.example .env
    echo "⚠️  Please edit backend/.env with your settings!"
    echo "   Default admin: admin@localhost / Admin@123456"
fi

if [ ! -d "node_modules" ]; then
    echo "Installing backend dependencies..."
    npm install
fi

echo "✓ Backend ready!"
echo ""

# Setup Frontend
echo "🔧 Setting up Frontend..."
cd ../frontend

if [ ! -d "node_modules" ]; then
    echo "Installing frontend dependencies..."
    npm install
fi

echo "✓ Frontend ready!"
echo ""

# Start the system
echo "🚀 Starting Email Admin System..."
echo "===================================="
echo ""
echo "Opening 2 terminals:"
echo "  Terminal 1: Backend (http://localhost:5000)"
echo "  Terminal 2: Frontend (http://localhost:3000)"
echo ""

# Start backend in background
cd ../backend
npm start &
BACKEND_PID=$!

# Wait a bit for backend to start
sleep 3

# Start frontend
cd ../frontend
npm start &
FRONTEND_PID=$!

echo ""
echo "✓ System started!"
echo ""
echo "🌐 Open http://localhost:3000 in your browser"
echo "🔐 Login with: admin@localhost / Admin@123456"
echo ""
echo "Press Ctrl+C to stop all services"
echo ""

# Wait for user interrupt
trap "kill $BACKEND_PID $FRONTEND_PID; exit" INT
wait
