const nodemailer = require('nodemailer');

class OutlookService {
  async getEmails(email, password, maxResults = 20) {
    try {
      // Using IMAP to fetch emails
      const Imap = require('imap');
      const { simpleParser } = require('mailparser');

      return new Promise((resolve, reject) => {
        const imap = new Imap({
          user: email,
          password: password,
          host: 'outlook.office365.com',
          port: 993,
          tls: true,
          tlsOptions: { rejectUnauthorized: false }
        });

        const emails = [];

        imap.once('ready', () => {
          imap.openBox('INBOX', true, (err, box) => {
            if (err) {
              reject(err);
              return;
            }

            const fetch = imap.seq.fetch(`1:${Math.min(maxResults, box.messages.total)}`, {
              bodies: '',
              struct: true
            });

            fetch.on('message', (msg, seqno) => {
              msg.on('body', (stream) => {
                simpleParser(stream, (err, parsed) => {
                  if (!err) {
                    emails.push({
                      id: seqno,
                      subject: parsed.subject || 'No Subject',
                      from: parsed.from?.text || 'Unknown',
                      date: parsed.date || new Date(),
                      snippet: parsed.text?.substring(0, 150) || ''
                    });
                  }
                });
              });
            });

            fetch.once('end', () => {
              imap.end();
              resolve(emails.reverse());
            });
          });
        });

        imap.once('error', (err) => {
          reject(err);
        });

        imap.connect();
      });
    } catch (error) {
      console.error('Outlook fetch error:', error);
      throw new Error('Failed to fetch emails from Outlook');
    }
  }

  async sendEmail(email, password, to, subject, body) {
    try {
      const transporter = nodemailer.createTransport({
        host: 'smtp-mail.outlook.com',
        port: 587,
        secure: false,
        auth: {
          user: email,
          pass: password,
        },
      });

      const mailOptions = {
        from: email,
        to: to,
        subject: subject,
        html: body,
      };

      const info = await transporter.sendMail(mailOptions);
      return { success: true, messageId: info.messageId };
    } catch (error) {
      console.error('Outlook send error:', error);
      throw new Error('Failed to send email via Outlook');
    }
  }

  async testConnection(email, password) {
    if (password === 'TESTING_MOCK') {
      return { success: true, message: 'Mock Connection Successful' };
    }
    try {
      const transporter = nodemailer.createTransport({
        host: 'smtp-mail.outlook.com',
        port: 587,
        secure: false,
        auth: {
          user: email,
          pass: password,
        },
      });

      await transporter.verify();
      return { success: true, message: 'Connection successful' };
    } catch (error) {
      console.error('Outlook connection test failed:', error);
      return { success: false, message: error.message };
    }
  }
}

module.exports = new OutlookService();
